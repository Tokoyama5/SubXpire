package com.example

import com.example.data.model.Subscription
import com.example.data.model.UrgencyLevel
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {

    @Test
    fun testUrgencyLevels() {
        val now = 1000000000L
        val expiredSub = Subscription(
            title = "Test",
            expiryTimestamp = now - 1000L
        )
        assertEquals(UrgencyLevel.EXPIRED, expiredSub.getUrgency(now))

        val criticalSub = Subscription(
            title = "Test",
            expiryTimestamp = now + TimeUnit.HOURS.toMillis(2)
        )
        assertEquals(UrgencyLevel.CRITICAL, criticalSub.getUrgency(now))

        val imminentSub = Subscription(
            title = "Test",
            expiryTimestamp = now + TimeUnit.HOURS.toMillis(10)
        )
        assertEquals(UrgencyLevel.IMMINENT, imminentSub.getUrgency(now))

        val upcomingSub = Subscription(
            title = "Test",
            expiryTimestamp = now + TimeUnit.DAYS.toMillis(4)
        )
        assertEquals(UrgencyLevel.UPCOMING, upcomingSub.getUrgency(now))
    }

    @Test
    fun testSubscriptionJsonSerialization() {
        val sub = Subscription(
            id = 42L,
            title = "Adobe Premiere Trial",
            category = "Free Trial",
            cost = 0.0,
            currency = "$",
            billingCycle = "One-time Trial",
            expiryTimestamp = 1700000000000L,
            leadHoursBeforeExpiry = 3,
            repeatIntervalMinutes = 30,
            note = "Remember to cancel on web before 3 PM!",
            serviceUrl = "adobe.com",
            isActive = true
        )

        val json = sub.toJsonObject()
        val parsed = Subscription.fromJsonObject(json)

        assertEquals(sub.id, parsed.id)
        assertEquals(sub.title, parsed.title)
        assertEquals(sub.category, parsed.category)
        assertEquals(sub.leadHoursBeforeExpiry, parsed.leadHoursBeforeExpiry)
        assertEquals(sub.repeatIntervalMinutes, parsed.repeatIntervalMinutes)
        assertEquals(sub.note, parsed.note)
        assertEquals(sub.isActive, parsed.isActive)
    }
}
