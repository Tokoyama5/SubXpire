package com.example.data.repository

import com.example.data.db.SubscriptionDao
import com.example.data.model.Subscription
import com.example.reminder.SubscriptionReminderManager
import kotlinx.coroutines.flow.Flow

class SubscriptionRepository(
    private val dao: SubscriptionDao,
    private val reminderManager: SubscriptionReminderManager
) {
    val allSubscriptions: Flow<List<Subscription>> = dao.getAllSubscriptions()
    val activeSubscriptions: Flow<List<Subscription>> = dao.getActiveSubscriptions()

    suspend fun insert(subscription: Subscription): Long {
        val newId = dao.insertSubscription(subscription)
        val created = subscription.copy(id = newId)
        if (created.isActive) {
            reminderManager.scheduleReminder(created)
        }
        return newId
    }

    suspend fun update(subscription: Subscription) {
        dao.updateSubscription(subscription)
        if (subscription.isActive) {
            reminderManager.scheduleReminder(subscription)
        } else {
            reminderManager.cancelReminder(subscription.id)
        }
    }

    suspend fun toggleActive(subscription: Subscription) {
        val updated = subscription.copy(isActive = !subscription.isActive)
        update(updated)
    }

    suspend fun delete(subscription: Subscription) {
        reminderManager.cancelReminder(subscription.id)
        dao.deleteSubscription(subscription)
    }

    suspend fun deleteById(id: Long) {
        reminderManager.cancelReminder(id)
        dao.deleteSubscriptionById(id)
    }

    suspend fun getAllSync(): List<Subscription> {
        return dao.getAllSubscriptionsSync()
    }

    suspend fun restoreSubscriptions(imported: List<Subscription>, replaceAll: Boolean) {
        if (replaceAll) {
            val existing = dao.getAllSubscriptionsSync()
            for (sub in existing) {
                reminderManager.cancelReminder(sub.id)
            }
            dao.deleteAll()
        }
        for (sub in imported) {
            // Clean id to avoid collision when merging
            val cleanSub = if (replaceAll) sub else sub.copy(id = 0)
            val newId = dao.insertSubscription(cleanSub)
            val inserted = cleanSub.copy(id = newId)
            if (inserted.isActive) {
                reminderManager.scheduleReminder(inserted)
            }
        }
    }

    fun testReminderNotification(subscription: Subscription) {
        reminderManager.showTestNotification(subscription)
    }
}
