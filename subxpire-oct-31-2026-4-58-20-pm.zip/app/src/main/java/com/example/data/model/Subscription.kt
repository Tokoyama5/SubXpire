package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class UrgencyLevel {
    EXPIRED,
    CRITICAL, // Less than 3 hours
    IMMINENT, // Less than 24 hours
    UPCOMING, // Within 7 days
    RELAXED   // More than 7 days
}

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String = "App", // Streaming, App, Free Trial, Website, Service, Other
    val serviceUrl: String = "",
    val cost: Double = 0.0,
    val currency: String = "$",
    val billingCycle: String = "Monthly", // Monthly, Yearly, One-time Trial, Weekly
    val expiryTimestamp: Long, // Epoch millis when subscription or trial expires
    val leadHoursBeforeExpiry: Int = 3, // Hours before expiry when reminders start (e.g. 2, 3, 24)
    val repeatIntervalMinutes: Int = 30, // Repeat reminder frequency (e.g. 30 min, 60 min, 120 min, 0=none)
    val note: String = "", // Notes: cancellation procedure, virtual card, promo terms, etc.
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastNotifiedAt: Long = 0L
) {
    fun getUrgency(now: Long = System.currentTimeMillis()): UrgencyLevel {
        if (!isActive) return UrgencyLevel.RELAXED
        val diff = expiryTimestamp - now
        return when {
            diff <= 0 -> UrgencyLevel.EXPIRED
            diff <= TimeUnit.HOURS.toMillis(3) -> UrgencyLevel.CRITICAL
            diff <= TimeUnit.HOURS.toMillis(24) -> UrgencyLevel.IMMINENT
            diff <= TimeUnit.DAYS.toMillis(7) -> UrgencyLevel.UPCOMING
            else -> UrgencyLevel.RELAXED
        }
    }

    fun getRemainingTimeFormatted(now: Long = System.currentTimeMillis()): String {
        val diff = expiryTimestamp - now
        if (diff <= 0) {
            val passed = -diff
            val hours = TimeUnit.MILLISECONDS.toHours(passed)
            val days = TimeUnit.MILLISECONDS.toDays(passed)
            return if (days > 0) "Expired $days day(s) ago" else "Expired $hours hour(s) ago"
        }
        val days = TimeUnit.MILLISECONDS.toDays(diff)
        val hours = TimeUnit.MILLISECONDS.toHours(diff) % 24
        val minutes = TimeUnit.MILLISECONDS.toMinutes(diff) % 60

        return when {
            days > 1 -> "$days days left"
            days == 1L -> "1 day $hours hr left"
            hours > 0 -> "${hours}h ${minutes}m left"
            else -> "${minutes}m left"
        }
    }

    fun getFormattedExpiryDate(): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy 'at' hh:mm a", Locale.getDefault())
        return sdf.format(Date(expiryTimestamp))
    }

    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("title", title)
            put("category", category)
            put("serviceUrl", serviceUrl)
            put("cost", cost)
            put("currency", currency)
            put("billingCycle", billingCycle)
            put("expiryTimestamp", expiryTimestamp)
            put("leadHoursBeforeExpiry", leadHoursBeforeExpiry)
            put("repeatIntervalMinutes", repeatIntervalMinutes)
            put("note", note)
            put("isActive", isActive)
            put("createdAt", createdAt)
            put("lastNotifiedAt", lastNotifiedAt)
        }
    }

    companion object {
        fun fromJsonObject(json: JSONObject): Subscription {
            return Subscription(
                id = json.optLong("id", 0L),
                title = json.optString("title", "Untitled Subscription"),
                category = json.optString("category", "App"),
                serviceUrl = json.optString("serviceUrl", ""),
                cost = json.optDouble("cost", 0.0),
                currency = json.optString("currency", "$"),
                billingCycle = json.optString("billingCycle", "Monthly"),
                expiryTimestamp = json.optLong("expiryTimestamp", System.currentTimeMillis() + 86400000L),
                leadHoursBeforeExpiry = json.optInt("leadHoursBeforeExpiry", 3),
                repeatIntervalMinutes = json.optInt("repeatIntervalMinutes", 30),
                note = json.optString("note", ""),
                isActive = json.optBoolean("isActive", true),
                createdAt = json.optLong("createdAt", System.currentTimeMillis()),
                lastNotifiedAt = json.optLong("lastNotifiedAt", 0L)
            )
        }
    }
}
