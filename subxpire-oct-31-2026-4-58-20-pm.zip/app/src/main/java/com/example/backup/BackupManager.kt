package com.example.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.model.Subscription
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupManager(private val context: Context) {

    fun generateJsonBackup(subscriptions: List<Subscription>): String {
        val root = JSONObject()
        root.put("app", "SubXpire")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("exportedAtFormatted", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        root.put("totalCount", subscriptions.size)

        val array = JSONArray()
        for (sub in subscriptions) {
            array.put(sub.toJsonObject())
        }
        root.put("subscriptions", array)
        return root.toString(2)
    }

    fun parseJsonBackup(jsonString: String): Result<List<Subscription>> {
        return try {
            val root = JSONObject(jsonString)
            val array = root.optJSONArray("subscriptions") ?: JSONArray()
            val list = mutableListOf<Subscription>()
            for (i in 0 until array.length()) {
                val itemObj = array.getJSONObject(i)
                list.add(Subscription.fromJsonObject(itemObj))
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun generateTextSummary(subscriptions: List<Subscription>): String {
        val sb = StringBuilder()
        sb.append("📋 SubAlert - Subscriptions & Trials Backup Summary\n")
        sb.append("Generated on: ${SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date())}\n")
        sb.append("Total Items: ${subscriptions.size}\n\n")

        for ((index, sub) in subscriptions.withIndex()) {
            sb.append("${index + 1}. ${sub.title} [${sub.category}]\n")
            sb.append("   • Status: ${if (sub.isActive) "Active" else "Cancelled/Inactive"}\n")
            sb.append("   • Expiry/Renewal: ${sub.getFormattedExpiryDate()} (${sub.getRemainingTimeFormatted()})\n")
            if (sub.cost > 0) {
                sb.append("   • Cost: ${sub.currency}${String.format(Locale.US, "%.2f", sub.cost)} / ${sub.billingCycle}\n")
            }
            sb.append("   • Reminders: ${sub.leadHoursBeforeExpiry}h lead time, repeat every ${if (sub.repeatIntervalMinutes > 0) "${sub.repeatIntervalMinutes}m" else "off"}\n")
            if (sub.note.isNotBlank()) {
                sb.append("   • Note: ${sub.note}\n")
            }
            if (sub.serviceUrl.isNotBlank()) {
                sb.append("   • Link: ${sub.serviceUrl}\n")
            }
            sb.append("\n")
        }
        return sb.toString()
    }

    fun writeToUri(uri: Uri, content: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    writer.write(content)
                    writer.flush()
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun readFromUri(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    reader.readText()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun createShareIntent(content: String, subject: String = "SubXpire Backup"): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, content)
        }
    }
}
