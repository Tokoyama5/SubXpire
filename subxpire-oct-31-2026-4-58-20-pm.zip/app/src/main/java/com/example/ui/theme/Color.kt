package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val LightPrimary = Color(0xFF1D4ED8)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFDBEAFE)
val LightOnPrimaryContainer = Color(0xFF1E3A8A)

val LightSecondary = Color(0xFF0F766E)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFCCFBF1)
val LightOnSecondaryContainer = Color(0xFF115E59)

val LightTertiary = Color(0xFFB45309)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFFEF3C7)
val LightOnTertiaryContainer = Color(0xFF78350F)

val LightBackground = Color(0xFFF8FAFC)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Colors
val DarkPrimary = Color(0xFF60A5FA)
val DarkOnPrimary = Color(0xFF0F172A)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkOnPrimaryContainer = Color(0xFFBFDBFE)

val DarkSecondary = Color(0xFF2DD4BF)
val DarkOnSecondary = Color(0xFF042F2E)
val DarkSecondaryContainer = Color(0xFF115E59)
val DarkOnSecondaryContainer = Color(0xFF99F6E4)

val DarkTertiary = Color(0xFFFBBF24)
val DarkOnTertiary = Color(0xFF451A03)
val DarkTertiaryContainer = Color(0xFF78350F)
val DarkOnTertiaryContainer = Color(0xFFFDE68A)

val DarkBackground = Color(0xFF0B1120)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkSurface = Color(0xFF131D31)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

// Status Accents
val UrgencyCritical = Color(0xFFEF4444)
val UrgencyImminent = Color(0xFFF97316)
val UrgencyUpcoming = Color(0xFFFBBF24)
val UrgencyRelaxed = Color(0xFF10B981)
