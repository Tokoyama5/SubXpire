package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subscription
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditSubscriptionSheet(
    existingSubscription: Subscription?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        title: String,
        category: String,
        cost: Double,
        currency: String,
        billingCycle: String,
        expiryTimestamp: Long,
        leadHours: Int,
        repeatInterval: Int,
        note: String,
        serviceUrl: String,
        isActive: Boolean
    ) -> Unit,
    onTestAlert: (Subscription) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val isEditing = existingSubscription != null

    var title by remember { mutableStateOf(existingSubscription?.title ?: "") }
    var note by remember { mutableStateOf(existingSubscription?.note ?: "") }
    var category by remember { mutableStateOf(existingSubscription?.category ?: "App") }
    var costText by remember { mutableStateOf(if (existingSubscription != null && existingSubscription.cost > 0) existingSubscription.cost.toString() else "") }
    var currency by remember { mutableStateOf(existingSubscription?.currency ?: "$") }
    var billingCycle by remember { mutableStateOf(existingSubscription?.billingCycle ?: "Monthly") }
    var expiryTimestamp by remember {
        mutableLongStateOf(
            existingSubscription?.expiryTimestamp ?: (System.currentTimeMillis() + TimeUnit.HOURS.toMillis(3))
        )
    }
    var leadHours by remember { mutableIntStateOf(existingSubscription?.leadHoursBeforeExpiry ?: 3) }
    var repeatInterval by remember { mutableIntStateOf(existingSubscription?.repeatIntervalMinutes ?: 30) }
    var serviceUrl by remember { mutableStateOf(existingSubscription?.serviceUrl ?: "") }
    var titleError by remember { mutableStateOf(false) }

    val categories = listOf("App", "Streaming", "Free Trial", "Website", "Service", "Other")
    val leadHourOptions = listOf(1, 2, 3, 6, 12, 24, 48)
    val repeatIntervalOptions = listOf(
        15 to "15 min",
        30 to "30 min",
        60 to "1 hour",
        120 to "2 hours",
        0 to "Once only"
    )

    fun showDatePicker() {
        val calendar = Calendar.getInstance().apply { timeInMillis = expiryTimestamp }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val updatedCal = Calendar.getInstance().apply {
                    timeInMillis = expiryTimestamp
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                }
                expiryTimestamp = updatedCal.timeInMillis
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    fun showTimePicker() {
        val calendar = Calendar.getInstance().apply { timeInMillis = expiryTimestamp }
        TimePickerDialog(
            context,
            { _, hourOfDay, minute ->
                val updatedCal = Calendar.getInstance().apply {
                    timeInMillis = expiryTimestamp
                    set(Calendar.HOUR_OF_DAY, hourOfDay)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }
                expiryTimestamp = updatedCal.timeInMillis
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            false
        ).show()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isEditing) "Edit Subscription" else "Register Subscription",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Register via note & configure repeated alerts",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_sheet_button")) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            // Quick Preset Suggestions (Only if adding new)
            if (!isEditing) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Quick Presets:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        onClick = {
                            title = "Amazon Prime 30-Day Trial"
                            category = "Free Trial"
                            costText = "0.00"
                            billingCycle = "One-time Trial"
                            expiryTimestamp = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(30)
                            leadHours = 24
                            repeatInterval = 60
                            note = "Remember to cancel 24h prior in Prime settings so auto-renewal does not trigger."
                        },
                        shape = RoundedCornerShape(100.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = "⚡ Amazon Trial (30d)",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium)
                        )
                    }

                    Surface(
                        onClick = {
                            title = "Adobe Creative Cloud Trial"
                            category = "Free Trial"
                            costText = "0.00"
                            billingCycle = "One-time Trial"
                            expiryTimestamp = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(7)
                            leadHours = 3
                            repeatInterval = 30
                            note = "Cancel at account.adobe.com/plans. Check registered virtual card."
                        },
                        shape = RoundedCornerShape(100.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = "⚡ Adobe Trial (7d)",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium)
                        )
                    }

                    Surface(
                        onClick = {
                            title = "Test Expiration (2 Hours)"
                            category = "App"
                            costText = "4.99"
                            billingCycle = "Monthly"
                            expiryTimestamp = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(2) + TimeUnit.MINUTES.toMillis(5)
                            leadHours = 2
                            repeatInterval = 15
                            note = "Test alert to verify repeated reminders (every 15 min)."
                        },
                        shape = RoundedCornerShape(100.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f)
                    ) {
                        Text(
                            text = "🔔 Test in 2 Hours",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title input
            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    if (it.isNotBlank()) titleError = false
                },
                label = { Text("Subscription / Offer / Website Name *") },
                placeholder = { Text("e.g. Netflix, Spotify, AWS, GitHub Pro") },
                isError = titleError,
                supportingText = if (titleError) { { Text("Name is required") } } else null,
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_title"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // The Note (Prominent!)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Registration Note & Cancellation Guide 📝") },
                placeholder = {
                    Text("e.g. Cancel before 4 PM on account page. Used virtual card ending in 8812. Promo discount expires today.")
                },
                minLines = 3,
                maxLines = 6,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_note"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Picker
            Text(
                text = "Category",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Expiration Date & Time Selection
            Text(
                text = "Expiration / Renewal Date & Time",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
            )
            val sdf = SimpleDateFormat("EEE, MMM dd, yyyy 'at' hh:mm a", Locale.getDefault())
            val formattedDate = sdf.format(Date(expiryTimestamp))

            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Expires: $formattedDate",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showDatePicker() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Change Date", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { showTimePicker() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Change Time", fontSize = 12.sp)
                        }
                    }

                    // Quick duration jumps
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "+2 Hours" to (2L * 3600_000L),
                            "+1 Day" to (24L * 3600_000L),
                            "+7 Days" to (7L * 86400_000L),
                            "+14 Days" to (14L * 86400_000L),
                            "+30 Days" to (30L * 86400_000L),
                            "+1 Year" to (365L * 86400_000L)
                        ).forEach { (label, duration) ->
                            Surface(
                                onClick = { expiryTimestamp = System.currentTimeMillis() + duration },
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            ) {
                                Text(
                                    text = label,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Reminder & Repeat Settings
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Repeated Expiration Alerts",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "1. Start alerting before expiration:",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        leadHourOptions.forEach { hours ->
                            FilterChip(
                                selected = leadHours == hours,
                                onClick = { leadHours = hours },
                                label = {
                                    Text(
                                        if (hours == 3) "3 hours (Rec.)" else if (hours >= 24) "${hours / 24}d prior" else "$hours hours"
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onTertiary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "2. Repeat alert frequency until cancelled:",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        repeatIntervalOptions.forEach { (mins, label) ->
                            FilterChip(
                                selected = repeatInterval == mins,
                                onClick = { repeatInterval = mins },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onTertiary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "SubXpire will notify you $leadHours hours before expiration and repeat ${if (repeatInterval > 0) "every $repeatInterval minutes" else "once"} until you cancel or renew.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cost, Currency & Billing Cycle Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    label = { Text("Cost") },
                    placeholder = { Text("0.00") },
                    prefix = { Text(currency) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = billingCycle,
                    onValueChange = { billingCycle = it },
                    label = { Text("Cycle") },
                    placeholder = { Text("Monthly") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Optional Website / Cancellation URL
            OutlinedTextField(
                value = serviceUrl,
                onValueChange = { serviceUrl = it },
                label = { Text("Website / Cancellation Link (Optional)") },
                placeholder = { Text("e.g. account.netflix.com") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Link, contentDescription = null)
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Save & Test buttons
            Button(
                onClick = {
                    if (title.isBlank()) {
                        titleError = true
                        return@Button
                    }
                    val parsedCost = costText.toDoubleOrNull() ?: 0.0
                    onSave(
                        existingSubscription?.id ?: 0L,
                        title,
                        category,
                        parsedCost,
                        currency,
                        billingCycle,
                        expiryTimestamp,
                        leadHours,
                        repeatInterval,
                        note,
                        serviceUrl,
                        existingSubscription?.isActive ?: true
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_subscription_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = if (isEditing) "Update Subscription" else "Save Subscription & Set Alarms",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Test Preview Alert
            OutlinedButton(
                onClick = {
                    val parsedCost = costText.toDoubleOrNull() ?: 0.0
                    val previewSub = Subscription(
                        id = existingSubscription?.id ?: 1L,
                        title = if (title.isBlank()) "Test Subscription" else title,
                        category = category,
                        cost = parsedCost,
                        currency = currency,
                        billingCycle = billingCycle,
                        expiryTimestamp = expiryTimestamp,
                        leadHoursBeforeExpiry = leadHours,
                        repeatIntervalMinutes = repeatInterval,
                        note = if (note.isBlank()) "Test preview alert for upcoming expiration" else note,
                        serviceUrl = serviceUrl,
                        isActive = true
                    )
                    onTestAlert(previewSub)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("preview_alert_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Test / Preview Notification Now", fontSize = 14.sp)
            }
        }
    }
}
