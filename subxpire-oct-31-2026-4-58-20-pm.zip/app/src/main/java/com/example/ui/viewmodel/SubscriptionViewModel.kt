package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.backup.BackupManager
import com.example.data.db.AppDatabase
import com.example.data.model.Subscription
import com.example.data.model.UrgencyLevel
import com.example.data.repository.SubscriptionRepository
import com.example.reminder.SubscriptionReminderManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class SubscriptionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SubscriptionRepository
    val backupManager: BackupManager

    init {
        val database = AppDatabase.getDatabase(application)
        val reminderManager = SubscriptionReminderManager(application)
        repository = SubscriptionRepository(database.subscriptionDao(), reminderManager)
        backupManager = BackupManager(application)
    }

    val allSubscriptions: StateFlow<List<Subscription>> = repository.allSubscriptions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _categoryFilter = MutableStateFlow("All")
    val categoryFilter = _categoryFilter.asStateFlow()

    private val _statusFilter = MutableStateFlow("All") // All, Expiring Soon, Active, Inactive
    val statusFilter = _statusFilter.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage = _toastMessage.asSharedFlow()

    // Dialog & UI states
    private val _selectedSubscription = MutableStateFlow<Subscription?>(null)
    val selectedSubscription = _selectedSubscription.asStateFlow()

    private val _isAddEditOpen = MutableStateFlow(false)
    val isAddEditOpen = _isAddEditOpen.asStateFlow()

    private val _editingSubscription = MutableStateFlow<Subscription?>(null)
    val editingSubscription = _editingSubscription.asStateFlow()

    private val _isBackupDialogVisible = MutableStateFlow(false)
    val isBackupDialogVisible = _isBackupDialogVisible.asStateFlow()

    val filteredSubscriptions: StateFlow<List<Subscription>> = combine(
        allSubscriptions,
        _searchQuery,
        _categoryFilter,
        _statusFilter
    ) { subs, query, category, status ->
        val now = System.currentTimeMillis()
        subs.filter { sub ->
            val matchesQuery = query.isBlank() ||
                    sub.title.contains(query, ignoreCase = true) ||
                    sub.note.contains(query, ignoreCase = true) ||
                    sub.category.contains(query, ignoreCase = true)

            val matchesCategory = category == "All" || sub.category.equals(category, ignoreCase = true)

            val matchesStatus = when (status) {
                "Active" -> sub.isActive
                "Inactive" -> !sub.isActive
                "Expiring Soon" -> sub.isActive && (sub.expiryTimestamp - now <= TimeUnit.HOURS.toMillis(24))
                else -> true
            }

            matchesQuery && matchesCategory && matchesStatus
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calculated metrics
    val activeCount: StateFlow<Int> = allSubscriptions.combine(_searchQuery) { subs, _ ->
        subs.count { it.isActive }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val urgentCount: StateFlow<Int> = allSubscriptions.combine(_searchQuery) { subs, _ ->
        val now = System.currentTimeMillis()
        subs.count { it.isActive && (it.expiryTimestamp - now <= TimeUnit.HOURS.toMillis(24)) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val monthlySpend: StateFlow<Double> = allSubscriptions.combine(_searchQuery) { subs, _ ->
        subs.filter { it.isActive }.sumOf { sub ->
            when (sub.billingCycle.lowercase()) {
                "monthly" -> sub.cost
                "yearly" -> sub.cost / 12.0
                "weekly" -> sub.cost * 4.33
                "quarterly" -> sub.cost / 3.0
                else -> 0.0
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    init {
        // Auto-seed sample subscriptions if empty so user has immediate context
        viewModelScope.launch {
            val existing = repository.getAllSync()
            if (existing.isEmpty()) {
                seedInitialData()
            }
        }
    }

    private suspend fun seedInitialData() {
        val now = System.currentTimeMillis()
        val sample1 = Subscription(
            title = "Adobe Photoshop Trial",
            category = "Free Trial",
            cost = 0.0,
            currency = "$",
            billingCycle = "One-time Trial",
            expiryTimestamp = now + TimeUnit.HOURS.toMillis(2) + TimeUnit.MINUTES.toMillis(45), // In ~2.75 hours!
            leadHoursBeforeExpiry = 3,
            repeatIntervalMinutes = 30,
            note = "Important: Cancel via Adobe Account > Plans before 5:00 PM to prevent $239.88 annual auto-charge! Card used: Virtual ending 4012.",
            serviceUrl = "account.adobe.com/plans",
            isActive = true
        )
        val sample2 = Subscription(
            title = "Netflix Premium 4K",
            category = "Streaming",
            cost = 22.99,
            currency = "$",
            billingCycle = "Monthly",
            expiryTimestamp = now + TimeUnit.DAYS.toMillis(3) + TimeUnit.HOURS.toMillis(6),
            leadHoursBeforeExpiry = 24,
            repeatIntervalMinutes = 60,
            note = "Shared family plan. Re-evaluate if anyone is still watching before renewal.",
            serviceUrl = "netflix.com/youraccount",
            isActive = true
        )
        val sample3 = Subscription(
            title = "Domain Name (myportfolio.dev)",
            category = "Website",
            cost = 14.50,
            currency = "$",
            billingCycle = "Yearly",
            expiryTimestamp = now + TimeUnit.DAYS.toMillis(14),
            leadHoursBeforeExpiry = 48,
            repeatIntervalMinutes = 120,
            note = "Renewal at Namecheap. Auth code saved in 1Password.",
            serviceUrl = "namecheap.com",
            isActive = true
        )
        repository.insert(sample1)
        repository.insert(sample2)
        repository.insert(sample3)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: String) {
        _categoryFilter.value = category
    }

    fun setStatusFilter(status: String) {
        _statusFilter.value = status
    }

    fun openAddDialog() {
        _editingSubscription.value = null
        _isAddEditOpen.value = true
    }

    fun openEditDialog(subscription: Subscription) {
        _editingSubscription.value = subscription
        _isAddEditOpen.value = true
    }

    fun closeAddEditDialog() {
        _isAddEditOpen.value = false
        _editingSubscription.value = null
    }

    fun selectSubscription(subscription: Subscription?) {
        _selectedSubscription.value = subscription
    }

    fun openBackupDialog() {
        _isBackupDialogVisible.value = true
    }

    fun closeBackupDialog() {
        _isBackupDialogVisible.value = false
    }

    fun saveSubscription(
        id: Long = 0,
        title: String,
        category: String,
        cost: Double,
        currency: String,
        billingCycle: String,
        expiryTimestamp: Long,
        leadHours: Int,
        repeatInterval: Int,
        note: String,
        serviceUrl: String,
        isActive: Boolean = true
    ) {
        viewModelScope.launch {
            val sub = Subscription(
                id = id,
                title = title.trim(),
                category = category,
                cost = cost,
                currency = currency,
                billingCycle = billingCycle,
                expiryTimestamp = expiryTimestamp,
                leadHoursBeforeExpiry = leadHours,
                repeatIntervalMinutes = repeatInterval,
                note = note.trim(),
                serviceUrl = serviceUrl.trim(),
                isActive = isActive
            )
            if (id == 0L) {
                repository.insert(sub)
                _toastMessage.emit("Registered subscription with reminders")
            } else {
                repository.update(sub)
                _toastMessage.emit("Updated subscription & reminders")
            }
            closeAddEditDialog()
            // Update selected if viewing detail
            if (_selectedSubscription.value?.id == id) {
                _selectedSubscription.value = sub
            }
        }
    }

    fun toggleActive(subscription: Subscription) {
        viewModelScope.launch {
            repository.toggleActive(subscription)
            val status = if (subscription.isActive) "marked as inactive/cancelled" else "reactivated"
            _toastMessage.emit("${subscription.title} $status")
            if (_selectedSubscription.value?.id == subscription.id) {
                _selectedSubscription.value = subscription.copy(isActive = !subscription.isActive)
            }
        }
    }

    fun deleteSubscription(subscription: Subscription) {
        viewModelScope.launch {
            repository.delete(subscription)
            _toastMessage.emit("Deleted ${subscription.title}")
            if (_selectedSubscription.value?.id == subscription.id) {
                _selectedSubscription.value = null
            }
        }
    }

    fun testReminder(subscription: Subscription) {
        repository.testReminderNotification(subscription)
        viewModelScope.launch {
            _toastMessage.emit("Preview alert sent for ${subscription.title}")
        }
    }

    fun restoreFromJson(jsonString: String, replaceAll: Boolean, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = backupManager.parseJsonBackup(jsonString)
            result.onSuccess { subs ->
                if (subs.isEmpty()) {
                    onComplete(false, "Backup file contains no subscriptions")
                } else {
                    repository.restoreSubscriptions(subs, replaceAll)
                    onComplete(true, "Successfully restored ${subs.size} subscriptions")
                    _toastMessage.emit("Restored ${subs.size} subscriptions from backup")
                }
            }.onFailure { err ->
                onComplete(false, "Invalid backup format: ${err.localizedMessage ?: "Unknown error"}")
            }
        }
    }
}
