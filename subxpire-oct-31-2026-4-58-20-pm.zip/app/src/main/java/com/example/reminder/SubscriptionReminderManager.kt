package com.example.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.Subscription
import java.util.concurrent.TimeUnit

class SubscriptionReminderManager(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_ID = "subalert_reminders_channel"
        const val CHANNEL_NAME = "Subscription Expiration Reminders"
        const val EXTRA_SUBSCRIPTION_ID = "extra_subscription_id"
        const val ACTION_TRIGGER_REMINDER = "com.example.action.TRIGGER_REMINDER"
        const val ACTION_MARK_CANCELLED = "com.example.action.MARK_CANCELLED"
        const val ACTION_SNOOZE = "com.example.action.SNOOZE"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = "Alerts and repeated reminders when subscriptions and trials are about to expire"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun scheduleReminder(subscription: Subscription) {
        if (!subscription.isActive) {
            cancelReminder(subscription.id)
            return
        }

        val now = System.currentTimeMillis()
        if (now >= subscription.expiryTimestamp) {
            // Already expired
            cancelReminder(subscription.id)
            return
        }

        val leadMillis = TimeUnit.HOURS.toMillis(subscription.leadHoursBeforeExpiry.toLong())
        val reminderStartMillis = subscription.expiryTimestamp - leadMillis

        val triggerAtMillis = when {
            now < reminderStartMillis -> reminderStartMillis
            subscription.repeatIntervalMinutes > 0 -> {
                // We are inside the reminder window!
                // Trigger repeat interval from now, but don't overshoot expiry
                val nextRepeat = now + TimeUnit.MINUTES.toMillis(subscription.repeatIntervalMinutes.toLong())
                if (nextRepeat < subscription.expiryTimestamp) nextRepeat else subscription.expiryTimestamp
            }
            else -> {
                // Lead time passed and no repeat configured
                subscription.expiryTimestamp
            }
        }

        val intent = Intent(context, SubscriptionReminderReceiver::class.java).apply {
            action = ACTION_TRIGGER_REMINDER
            putExtra(EXTRA_SUBSCRIPTION_ID, subscription.id)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            subscription.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }

    fun cancelReminder(subscriptionId: Long) {
        val intent = Intent(context, SubscriptionReminderReceiver::class.java).apply {
            action = ACTION_TRIGGER_REMINDER
            putExtra(EXTRA_SUBSCRIPTION_ID, subscriptionId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            subscriptionId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
        notificationManager.cancel(subscriptionId.toInt())
    }

    fun showNotification(subscription: Subscription) {
        val now = System.currentTimeMillis()
        val remaining = subscription.getRemainingTimeFormatted(now)

        // Launch app intent
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_SUBSCRIPTION_ID, subscription.id)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            subscription.id.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Mark cancelled action
        val cancelIntent = Intent(context, SubscriptionReminderReceiver::class.java).apply {
            action = ACTION_MARK_CANCELLED
            putExtra(EXTRA_SUBSCRIPTION_ID, subscription.id)
        }
        val cancelPendingIntent = PendingIntent.getBroadcast(
            context,
            (subscription.id * 10 + 1).toInt(),
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze action
        val snoozeIntent = Intent(context, SubscriptionReminderReceiver::class.java).apply {
            action = ACTION_SNOOZE
            putExtra(EXTRA_SUBSCRIPTION_ID, subscription.id)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (subscription.id * 10 + 2).toInt(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val noteText = if (subscription.note.isNotBlank()) {
            "\n📝 Note: ${subscription.note}"
        } else ""

        val costInfo = if (subscription.cost > 0) {
            " (${subscription.currency}${String.format(java.util.Locale.US, "%.2f", subscription.cost)}/${subscription.billingCycle})"
        } else ""

        val bigText = "Your ${subscription.category} subscription '${subscription.title}'$costInfo is about to expire ($remaining).$noteText"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⚠️ ${subscription.title} expires soon!")
            .setContentText("Expires in $remaining. Tap to view notes & cancel instructions.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(0, "Mark as Cancelled", cancelPendingIntent)
            .addAction(0, "Snooze 30m", snoozePendingIntent)
            .build()

        notificationManager.notify(subscription.id.toInt(), notification)
    }

    fun showTestNotification(subscription: Subscription) {
        val testSub = subscription.copy(id = 999999L)
        showNotification(testSub)
    }
}
