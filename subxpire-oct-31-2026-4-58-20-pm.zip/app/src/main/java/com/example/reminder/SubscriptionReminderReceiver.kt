package com.example.reminder

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class SubscriptionReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val subscriptionId = intent.getLongExtra(SubscriptionReminderManager.EXTRA_SUBSCRIPTION_ID, -1L)
        if (subscriptionId == -1L) return

        val reminderManager = SubscriptionReminderManager(context)
        val database = AppDatabase.getDatabase(context)
        val dao = database.subscriptionDao()

        when (intent.action) {
            SubscriptionReminderManager.ACTION_TRIGGER_REMINDER -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val sub = dao.getSubscriptionById(subscriptionId)
                    if (sub != null && sub.isActive) {
                        reminderManager.showNotification(sub)
                        dao.updateLastNotified(subscriptionId, System.currentTimeMillis())

                        val now = System.currentTimeMillis()
                        // If repeating reminders enabled and not expired yet, schedule next repeated reminder
                        if (sub.repeatIntervalMinutes > 0 && now < sub.expiryTimestamp) {
                            reminderManager.scheduleReminder(sub)
                        }
                    }
                }
            }

            SubscriptionReminderManager.ACTION_MARK_CANCELLED -> {
                CoroutineScope(Dispatchers.IO).launch {
                    dao.updateActiveStatus(subscriptionId, false)
                    reminderManager.cancelReminder(subscriptionId)
                }
            }

            SubscriptionReminderManager.ACTION_SNOOZE -> {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(subscriptionId.toInt())

                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val snoozeTime = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(30)

                val triggerIntent = Intent(context, SubscriptionReminderReceiver::class.java).apply {
                    action = SubscriptionReminderManager.ACTION_TRIGGER_REMINDER
                    putExtra(SubscriptionReminderManager.EXTRA_SUBSCRIPTION_ID, subscriptionId)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    subscriptionId.toInt(),
                    triggerIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                try {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        snoozeTime,
                        pendingIntent
                    )
                } catch (_: SecurityException) {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, snoozeTime, pendingIntent)
                }
            }
        }
    }
}
