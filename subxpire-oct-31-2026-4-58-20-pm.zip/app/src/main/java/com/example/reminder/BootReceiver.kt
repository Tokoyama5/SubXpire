package com.example.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val reminderManager = SubscriptionReminderManager(context)
            val database = AppDatabase.getDatabase(context)
            val dao = database.subscriptionDao()

            CoroutineScope(Dispatchers.IO).launch {
                val activeSubs = dao.getActiveSubscriptionsSync()
                val now = System.currentTimeMillis()
                for (sub in activeSubs) {
                    if (sub.expiryTimestamp > now) {
                        reminderManager.scheduleReminder(sub)
                    }
                }
            }
        }
    }
}
